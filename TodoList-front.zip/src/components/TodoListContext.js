import React, { createContext } from 'react';

/* 전역 변수 역할의 객체 생성 */
const TodoListContext = createContext();

export default TodoListContext;